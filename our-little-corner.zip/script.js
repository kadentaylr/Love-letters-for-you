async function load(){
 const letters=await fetch('letters.json').then(r=>r.json());
 const latest=letters[0];
 document.getElementById('latest').innerHTML=`<div class='note'><h3>${latest.title}</h3><small>${latest.date}</small><p>${latest.message}</p></div>`;
 document.getElementById('archive').innerHTML=letters.map(l=>`<div class='note'><h3>${l.title}</h3><small>${l.date}</small><p>${l.message}</p></div>`).join('');
 const photos=await fetch('photos.json').then(r=>r.json());
 document.getElementById('gallery').innerHTML=photos.map(p=>`<div class='photo'><img src='photos/${p.file}' alt=''><h4>${p.title}</h4><p>${p.note}</p></div>`).join('');
}
load();
